import java.io.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.time.*;
import java.time.format.*;

@WebServlet("/simple")

public class FirstServlet extends HttpServlet
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException
	{
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		
		String name=req.getParameter("name");

//		HttpSession session=req.getSession();
//		session.setAttribute("nam", name);
//		
//		out.println("<center><h1>");
//		out.println("Welcome To Java Programming World");
//		out.println("</h1></center>");
		if(name.equals("Mohammed"))
		{
			RequestDispatcher rd=req.getRequestDispatcher("success.jsp");
		    rd.forward(req,res);
		}
		else
		{
			out.println("This Name Is Not Available Ever DataBase");
		}
        
		
//		DateTimeFormatter ed=DateTimeFormatter.ofPattern("dd-mm-yyyy  hh:mm:ss");
//		LocalDateTime d=LocalDateTime.now();
//		out.println("<br><br>");
//		out.println("<h3 style='text-align:right'>");
//		out.println(ed.format(d));
//		out.println("</h3>");
//		out.println("<br><hr><hr><br><br>");
//		out.println("Hi:"+name);
	}

}
