import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;
import javax.servlet.annotation.*;

@WebServlet("/add")
public class FirstServlet extends HttpServlet
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException,ServletException
	{
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		
		Integer number1=Integer.parseInt(req.getParameter("num1"));
		Integer number2=Integer.parseInt(req.getParameter("num2"));
		
		int add=number1+number2;
		out.println("<html><body style='background-image:linear-gradient(green,red)'><center><h1>");
		out.println("Welcome Servlet Technology");
		out.println("</h1></center>");
		out.println("<br><br><h2 style='color:white'>");
		out.println("Addition Of Two Numbers:"+add);
		out.println("</h2></body></html>");
	}

}
