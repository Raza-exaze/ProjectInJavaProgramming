package Game.Project.FirstGame;

import java.util.Random;
import java.util.Scanner;

public class App 
{
    public static void main( String[] args )
    {
    	//System Objects
    	Scanner in=new Scanner(System.in);
    	Random rand=new Random();
    	System.out.println("Enter Your Name:");
    	String name=in.nextLine();
    	
    	//Game Variables
    	String[] enemies= {"SKELETON","ZOMBIE","WARRIOR","ASSASSIN"};
    	int maxEnemyHealth=75;
    	int enemyAttackDamage=25;
    	
    	//Player Variables
    	int health=100;
    	int attackDamage=50;
    	int numHealthPotions=3;
    	int healthPotionHealAmount=30;
    	int healthPotionDropChance=50; //Percentage
    	boolean running=true;
    	System.out.println("............................");
    	System.out.println("WELCOME TO THE DUNGEON GAME");
    	GAME:
    		while(running)
    		{
    			System.out.println("..........................................");
    			
    			int enemyHealth=rand.nextInt(maxEnemyHealth);
    			String enemy=enemies[rand.nextInt(enemies.length)];
    			System.out.println("\t"+enemy+"HAS APPEARED!\n");
    			while(enemyHealth>0)
    			{
    				System.out.println("\tYOUR HP:"+health);
    				System.out.println("\t"+enemy+"'s HP:"+enemyHealth);
    				System.out.println("\n\tWHAT WOULD YOU LIKE TO DO NOW?");
    				System.out.println("\t1. ATTACK");
    				System.out.println("\t2. DRINK HEALTH POWER JUICE");
    				System.out.println("\t3. RUN!");
    				System.out.println("ENTER YOUR NUMBER HERE:");
    				String input=in.nextLine();
    				if(input.equals("1"))
    				{
    					int damageDealt=rand.nextInt(attackDamage);
    					int demageTaken=rand.nextInt(enemyAttackDamage);
    					enemyHealth -=damageDealt;
    					health-=demageTaken;
    					System.out.println("\t> YOU STRIKE THE "+enemy+" FOR "+damageDealt+" DAMAGE.");
    					System.out.println("\t> YOU RECIEVE "+demageTaken+" IN RATALIATION");
    					if(health<1)
    					{
    						System.out.println("\t> YOU HAVE TAKEN TOO MUCH DAMAGE, YOU  ARE TOO WEAK TO GO ON!");
    						break;
    						
    					}
    					
    				}
    				else if(input.equals("2"))
    				{
    					if(numHealthPotions>0)
    					{
    						health +=healthPotionHealAmount;
    						numHealthPotions--;
    						System.out.println("\t> YOU DRINK A HEALTH POWER JUICE, HEALING YOURSELF FOR "+healthPotionHealAmount+"\n\t> YOU ARE NOW HAVE "+health+" HP. "+"\n\t> YOU HAVE "+numHealthPotions+" HEALTH POWER JUICE LEFT.\n");
    						
    					}
    					else
    					{
    						System.out.println("\t> YOU HAVE NO HEALTH POWER JUICE LEFT! DEFEAT ENEMIES FOR A CHANCE TO GET ONE!\t");
    					}
    				}
    				else if(input.equals("3"))
    				{
    					System.out.println("\t YOU RUN AWAY FROM THE "+enemy+"!");
    					continue GAME;
    				}
    				else
    				{
    					System.out.println("\t INVALID COMMAND!");
    				}
    			}
    			if(health<1)
    			{
    				System.out.println("YOU LIMP OUT OF THE DUNGEON, WEAK FROM BATTLE!");
    				break;
    			}
    			System.out.println("-------------------------------------------------");
    			System.out.println("#"+enemy+" WAS DEFEATED! #");
    			System.out.println("# YOU HAVE "+health+" HP LEFT. #");
				if(rand.nextInt(100) < healthPotionDropChance)
				{
					numHealthPotions++;
					System.out.println("# THE "+enemy+" DROPPED A HEALTH POWER JUICE! #");
					System.out.println("# YOU NOW HAVE "+numHealthPotions+" HEALTH POWER JUICE(S). #");
				}
				System.out.println("-------------------------------------------------");
				System.out.println("WHAT WOULD YOU LIKE TO DO NOW?");
				System.out.println("1. CONTINUE FIGHTING");
				System.out.println("2. EXIT DUNGEON");
				System.out.println("ENTER YOUR OPTION HERE:");
				String input=in.nextLine();
				while(!input.equals("1") && !input.equals("2"))
				{
					System.out.println("INVALID COMMAND");
					input=in.nextLine();
				}
				if(input.equals("1"))
				{
					System.out.println("YOU CONTINUE ON YOUR ADVENTURE!");
				}
				else if(input.equals("2"))
				{
					System.out.println("YOU EXIT THE DUNGEON, SUCCESSFUL FROM YOUR ADVENTURES!");
					break;
				}
    		}
    	System.out.println("************************************************");
    	System.out.println("*  THANKS FOR PLAYING THIS GAME "+name.toUpperCase()+"*");
    	System.out.println("************************************************");
        
    }
}
