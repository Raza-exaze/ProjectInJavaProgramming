package FirstServlet;

import java.sql.*;

public class DaoLayer 
{
public boolean check(String name)
{
	boolean status=false;
	public static void main(String[] args) throws ClassNotFoundException
	{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","");
        PreparedStatement ps=con.prepareStatement("select * from student where name=?");
		ps.setString(2,"");
		ResultSet rs=ps.executeQuery();
		status=rs.next();
	}
	return status;
}
}
