import java.sql.*;

public class ExampleDao 
{
	public boolean check(String country,String city)
	{
		boolean status=false;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","systemroot@786");
			PreparedStatement ps=con.prepareStatement("select * from country where country=? and city=?");
			ps.setString(1, country);
			ps.setString(2, city);
			
			ResultSet rs=ps.executeQuery();
			status=rs.next();
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return status;
	}

}
