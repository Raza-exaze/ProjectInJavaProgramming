import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.*;

public class ExampleServlet extends HttpServlet
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest req,HttpServletResponse res)
	{
		try
		{
			res.setContentType("text/html");
			PrintWriter out=res.getWriter();
			
			String name=req.getParameter("country");
			String names=req.getParameter("city");
			
			req.setAttribute("nam", names);
			
			ExampleDao a=new ExampleDao();
			if(a.check(name,names))
					{
				RequestDispatcher rd=req.getRequestDispatcher("Success.jsp");
				rd.forward(req, res);
					}
			else
			{
				out.println("<h2 style='background-color:red'>");
				out.println("Enter The Country And City Is Not Available Ever DataBase");
				out.println("</h2>");
				RequestDispatcher rd=req.getRequestDispatcher("index.jsp");
				rd.include(req, res);
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

}
