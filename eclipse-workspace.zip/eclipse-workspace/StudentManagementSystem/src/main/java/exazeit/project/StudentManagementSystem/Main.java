package exazeit.project.StudentManagementSystem;

import java.util.*;

import java.util.List;

public class Main 
{
	public static void main(String args[])
	{
		Teacher lizzy=new Teacher(1,"Lizzy",500);
		Teacher Priya=new Teacher(2,"Priya",600);
		Teacher Divya=new Teacher(3,"Divya",800);
		
		List<Teacher> teacherlist=new ArrayList<Teacher>();
		teacherlist.add(lizzy);
		teacherlist.add(Divya);
		teacherlist.add(Priya);
		
		Student Imran=new Student(1,"Imran",1);
		Student Khan=new Student(2,"Khan",2);
		
		List<Student> studentlist=new ArrayList<Student>();
		studentlist.add(Khan);
		studentlist.add(Imran);
		
		School ghs=new School(teacherlist,studentlist);
		Imran.payFees(10000);
		System.out.println("GHS Has Earned:$"+ghs.getTotalMoneyEarned());
		Khan.payFees(2000);
		System.out.println("GHS Has Earned:$"+ghs.getTotalMoneyEarned());
		
		System.out.println("-------Making School Pay Salary---------");
		lizzy.recieveSalary(500);
		System.out.println("Lizzy Recieved Salary:$"+ghs.getTotalMoneyEarned());
		Divya.recieveSalary(Divya.getSalary());
		System.out.println("Divya Recieved Salary:$"+ghs.getTotalMoneyEarned());
		System.out.println(Imran);
		System.out.println(Divya);

	}

}
