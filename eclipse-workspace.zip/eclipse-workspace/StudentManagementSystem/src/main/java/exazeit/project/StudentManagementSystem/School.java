package exazeit.project.StudentManagementSystem;

import java.util.*;

/**
 * 
 * @author
 * In School Many Teachers & Students.
 * Implementation Teachers and Students using ArrayList Collections FrameWork.
 */

public class School 
{
	private List<Teacher> teachers;
	private List<Student> students;
	private static int totalMoneyEarned;
	private static int totalMoneySpent;
	
	/**
	 * new School Object is Created.
	 * @param teachers list of teachers in the school.
	 * @param students list of students in the school.
	 */
	public School(List<Teacher> teacher,List<Student> student)
	{
		this.teachers=teacher;
		this.students=student;
		totalMoneyEarned=0;
		totalMoneySpent=0;
	}
	/**
	 * 
	 * @return The List Of Teachers in The School.
	 */

	public List<Teacher> getTeachers() {
		return teachers;
	}

	public void addTeacher(Teacher teacher) {
		teachers.add(teacher);
	}
	/**
	 * 
	 * @return List Of Student in the School.
	 */

	public List<Student> getStudent() {
		return students;
	}

	public void addStudent(Student student) {
	       students.add(student);
	}

	public int getTotalMoneyEarned() {
		return totalMoneyEarned;
	}

	public static void updateTotalMoneyEarned(int MoneyEarned) {
		totalMoneyEarned += MoneyEarned;
	}

	public int getTotalMoneySpent() {
		return totalMoneySpent;
	}

	public static void updateTotalMoneySpent(int MoneySpent) {
		totalMoneySpent -= MoneySpent;
	}
	

}
