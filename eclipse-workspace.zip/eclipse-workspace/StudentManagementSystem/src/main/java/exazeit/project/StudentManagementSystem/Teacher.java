package exazeit.project.StudentManagementSystem;

/**
 * 
 * @author Mohammed Razaullah
 * This Class is Responsible for keeping the track
 * of Teacher's name,id & salary.
 */

public class Teacher 
{
	private int id;
	private String name;
	private int salary;
	private int salaryEarned;
	/**
	 * create a new Teacher object.
	 * @param id id for the Teacher.
	 * @param name name of the Teacher.
	 * @param salary Salary of the Teacher.
	 */
	
	public Teacher(int id,String name,int salary)
	{
		this.id=id;
		this.name=name;
		this.salary=salary;
		this.salaryEarned=0;
	}
	/**
	 * 
	 * @return Id of The Teacher.
	 */
	public int getId()
	{
		return id;
	}
	/**
	 * 
	 * @return Name Of The Teacher.
	 */
	public String getName()
	{
		return name;
	}
	/**
	 * 
	 * @return Salary of The Teacher.
	 */
	public int getSalary()
	{
		return salary;
	}
	
	public void setSalary(int salary)
	{
		this.salary=salary;
	}
	
	public void recieveSalary(int salary)
	{
		salaryEarned += salary;
		School.updateTotalMoneySpent(salary);
	}
	@Override
	public String toString() {
		return "Teacher [id=" + id + ", name=" + name + ", salary=" + salary + ", salaryEarned=" + salaryEarned + "]";
	}

}
