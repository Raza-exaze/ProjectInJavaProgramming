package com.javas;

import com.java.First;

public class Second 
{
	public static void main(String args)
	{
		First f=new First();
		f.fun();
	}

}
