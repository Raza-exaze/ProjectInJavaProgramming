package com.java;

public class First 
{
	public void fun()
	{
		System.out.println("Hello Java Programmer");
	}

}
