import java.io.IOException;
import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet("/add")

public class FirstServlet extends HttpServlet
{
/**
	 *
	 */
	private static final long serialVersionUID = 1L;

public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException
{
		PrintWriter out=res.getWriter();
		
		int num1=Integer.parseInt(req.getParameter("n1"));
		int num2=Integer.parseInt(req.getParameter("n2"));
		
		int sum=num1+num2;
		
		out.println("Addition Of Two Number:"+sum);
	
}

}