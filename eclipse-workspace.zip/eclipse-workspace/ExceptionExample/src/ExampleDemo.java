class Demo extends Exception
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Demo(String str)
	{
		super(str);
	}
}
public class ExampleDemo 
{
	public void see(int age) throws Demo
	{
		if(age<18)
		{
			throw new Demo("Age Is Not Sufficient For Vote");
		}
		else
		{
			System.out.println("Welcome To Voting System");
		}
	}
		public static void main(String[] args)
		{
			try
			{
				ExampleDemo d=new ExampleDemo();
			d.see(19);
		}catch(Exception e)
			{
			System.out.println(e.getMessage());
			}
}
}
