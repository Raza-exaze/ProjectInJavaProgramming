

import java.io.IOException;
import java.util.List;
import java.io.File;
import java.io.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
//import org.apache.tomcat.jni.File;
//import org.apache.tomcat.util.http.fileupload.FileItem;


public class UploadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		ServletFileUpload sr=new ServletFileUpload(new DiskFileItemFactory());
		List<org.apache.commons.fileupload.FileItem> sub;
		try {
			sub = sr.parseRequest(request);
		
		for(org.apache.commons.fileupload.FileItem item: sub)
		{
			item.write(new File("/Users/Dell/Downloads/File/"+item.getName()));
		}
		out.println("File Uploaded");
	} catch (Exception e) {
		
	 out.println("Error Message:"+e.getMessage());
	}
	}
}
