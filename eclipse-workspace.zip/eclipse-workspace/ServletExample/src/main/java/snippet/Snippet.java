

public class Snippet {
	public static void main(String[] args) {
		<!-- https://mvnrepository.com/artifact/org.hibernate/hibernate-entitymanager -->
		<dependency>
		    <groupId>org.hibernate</groupId>
		    <artifactId>hibernate-entitymanager</artifactId>
		    <version>6.0.0.Alpha7</version>
		    <type>pom</type>
		</dependency>
		
	}

	public static void main(String[] args) {
		<!-- https://mvnrepository.com/artifact/org.hibernate/hibernate-entitymanager -->
		<dependency>
		    <groupId>org.hibernate</groupId>
		    <artifactId>hibernate-entitymanager</artifactId>
		    <version>6.0.0.Alpha7</version>
		    <type>pom</type>
		</dependency>
		
	}
}