
import com.project.model.Connected;

public class MessageDao 
{
	public Connected getConnect(int num)
	{
		
	Connected c=new Connected();
	c.setId(1);
	c.setName("Java");
	c.setPhone(32445433);
	
	return c;
	}
	

}
