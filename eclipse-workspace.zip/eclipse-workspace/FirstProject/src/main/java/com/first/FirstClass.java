package com.first;

public class FirstClass {
	public void Func()
	{
		System.out.println("Hello Java Programmer");
		int b=33;
		int c=44;
		int f=b+c;
		System.out.println("Addition Of Numbers:"+f);
	}

}
