package com.second;

import com.first.FirstClass;

public class SecondClass {
	
	public static void main(String args[])
	{
	
	FirstClass fc=new FirstClass();
	fc.Func();
	}
}
