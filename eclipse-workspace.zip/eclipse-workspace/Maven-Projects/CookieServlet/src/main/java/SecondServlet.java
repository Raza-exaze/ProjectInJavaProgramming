import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;

public class SecondServlet extends HttpServlet
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		
		Cookie ck[]=req.getCookies();
		out.println("Welcome To Cookie Side");
		out.println("<br>");
		out.println("Hello:"+ck[0].getValue());
		out.println("<br>");
		out.println("DomainName:"+ck[0].getDomain());
		out.println("<br>");
		out.println("MaxAge Cookie:"+ck[0].getMaxAge());
		out.println("<br>");
		out.println("Name Of Cookie:"+ck[0].getName());
		out.println("<br>");
		out.println("Path of Cookie:"+ck[0].getPath());
		out.println("<br>");
		out.println("Secure Of Cookie:"+ck[0].getSecure());
		
		out.close();
		
	}

}
