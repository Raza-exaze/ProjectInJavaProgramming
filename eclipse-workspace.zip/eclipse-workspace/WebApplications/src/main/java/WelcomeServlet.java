import java.io.IOException;  
import java.io.PrintWriter;  
  
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse; 
  
public class WelcomeServlet extends HttpServlet {  
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public void doPost(HttpServletRequest request, HttpServletResponse response)  
    throws ServletException, IOException {  
  
    response.setContentType("text/html");  
    PrintWriter out = response.getWriter();  
          
    String n=request.getParameter("name");
    out.println("<html><body bgcolor='green'><h1 style='text-align:center;background-color:yellow'>");
    out.println("<br><br>");
    out.println("<hr><hr>");
    out.print("Welcome: "+n);  
    out.println("<hr><hr>");
    out.println("</h1>");
    out.println("<h4><marquee style='text-color:white';'direction:right'>");
    out.println("Now You Are Successfully Connected to Your Account");
    out.println("</marquee></h4>");
    out.println("</body></html>");
          
    out.close();  
    }  
  
} 