

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ExampleServlet extends HttpServlet 
{
       
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setContentType("text/html");  
	    PrintWriter out = response.getWriter();  
	          
	    String n=request.getParameter("name");  
	    String p=request.getParameter("pass"); 
	    
	    ExampleDao ed=new ExampleDao();
	          
	    if(ed.validate(n, p)){  
	        RequestDispatcher rd=request.getRequestDispatcher("WelcomeServlet");  
	        rd.forward(request,response);  
	    }  
	    else{  
	    	out.println("<html><body style='background-color:lightgreen'><center><h3 style='color:black'>");
	        out.print("User Name Or Password Incorrect Try Again Later"); 
	        out.println("<br><br>");
	        out.println("Sorry Not Able To Connect Existing Server Page");
	        out.println("</h3></center></body></html>");
	        RequestDispatcher rd=request.getRequestDispatcher("index.jsp");  
	        rd.include(request,response);  
	        out.println("<h2 style='color:white'>Wrong Input Enter");
	        out.println("<br>");
	        out.println("Check Once And Try Again Later</h2>");
	    }  
	          
	    out.close();  
	    }  
	
	
	}

