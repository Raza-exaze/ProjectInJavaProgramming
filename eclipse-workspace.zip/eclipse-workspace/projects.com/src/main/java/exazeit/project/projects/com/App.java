package exazeit.project.projects.com;

/**
 * Hello world!
 *
 */
public class App 
{
    public void fun()
    {
        System.out.println( "Hello World!" );
    }
}
