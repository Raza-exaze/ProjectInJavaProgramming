package Projects.coms;

import exazeit.project.projects.com.App;

public class Second
{
	public static void main(String args)
	{
		App a=new App();
		a.fun();
	}

}
