import com.java.Connected;
public class ConnectedDao 
{
public Connected getConnect(int num)
{
	Connected c=new Connected();
	c.setId(1);
	c.setName("Java");
	return c;
}
}
