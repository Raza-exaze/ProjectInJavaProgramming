package com.java.Dao;
import java.io.*;
import java.sql.*;


public class DaoServlet {
	public static void main(String args[]) throws IOException,SQLException,ClassNotFoundException
	{
	Class.forName("com.mysql.jdbc.Driver");
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","system","systemroot@786");
	PreparedStatement ps=con.prepareStatement("select * from user where name=?");
	ps.setString(1,"name");
	ResultSet res=ps.executeQuery();
	}

}
