package com.java;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import com.java.Dao.DaoServlet;

@WebServlet("/add")

public class AddServlet extends GenericServlet{
	public void service(ServletRequest req,ServletResponse res) throws IOException,ServletException
	{
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		String name=req.getParameter("name");
		out.println("Welcome: "+name);
		out.println("<br>");
		int i=1;
		for(i=1;i<=name.length()-1;i++)
		{
			out.println();
		}
		out.println("Character Of Words:"+i);
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","system","systemroot@786");
			PreparedStatement ps=con.prepareStatement("insert into user values name=?");
			ps.setString(1,"name");
			ResultSet rs=ps.executeQuery();
		
	if(name.equals(rs.getString(0)))
	{
		out.println("Welcome");
	}
	else
	{
		out.println("Name Is Not Available");
	}
		}catch(Exception e)
		{
			out.println("Error Message:"+e.getMessage());
		}
	}

}
