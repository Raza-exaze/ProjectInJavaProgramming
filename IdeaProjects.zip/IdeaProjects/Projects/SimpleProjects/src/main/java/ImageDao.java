import java.sql.*;
import java.io.*;

public class ImageDao {
    public static void main(String[] args) {
        System.out.println("Insert Image Example!");
        String driverName = "com.mysql.jdbc.Driver";
        String url = "jdbc:mysql://localhost:3306/";
        String dbName = "student";
        String userName = "root";
        String password = "systemroot@786";
        Connection con = null;
        try{
            Class.forName(driverName);
            con = DriverManager.getConnection(url+dbName,userName,password);
            Statement st = con.createStatement();
            File imgfile = new File("d://charminar.jpg");
            FileInputStream fin = new FileInputStream(imgfile);
            PreparedStatement pre = con.prepareStatement("insert into image values(?,?)");
            pre.setString(1,"charminar");
            pre.setBinaryStream(2,fin,(int)imgfile.length());
            // pre.setBinaryStream(3,fin,fin.available());
            pre.executeUpdate();
            System.out.println("Inserting Successfully!");
            pre.close();
            con.close();
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

}