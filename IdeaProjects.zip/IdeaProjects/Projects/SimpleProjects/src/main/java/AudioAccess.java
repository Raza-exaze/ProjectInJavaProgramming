import java.io.*;
import java.sql.*;

public class AudioAccess {
    public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "systemroot@786");
        Statement ps = con.createStatement();
        ResultSet rs = ps.executeQuery("select * from audio");
        if (rs.next()) {
            Blob b = rs.getBlob(1);
            byte bb[] = b.getBytes(1, (int) b.length());

            FileOutputStream fis = new FileOutputStream("d://abc.mp3");
            fis.write(bb);
            fis.close();
        }
        System.out.println("Audio File Is Successfully Update In D Drive");
    }
}