import java.util.*;

public class ComparatorsInterface {
    int roll;
    String name;
    int age;

    ComparatorsInterface(int roll, String name, int age) {
        this.roll = roll;
        this.name = name;
        this.age = age;
    }
}
class AgeComparator implements Comparator<ComparatorsInterface>
{
    @Override
    public int compare(ComparatorsInterface c1, ComparatorsInterface c2) {
        if(c1.age==c2.age)
            return 0;
        else if(c1.age>c2.age)
            return 1;
        else
            return -1;
    }
}
class NameComparator implements Comparator<ComparatorsInterface>
{
    @Override
    public int compare(ComparatorsInterface c1, ComparatorsInterface c2) {

        return c1.name.compareTo(c2.name);
    }
}
class TestExam
{
public static void main(String args[])
{
    List<ComparatorsInterface> l=new ArrayList<ComparatorsInterface>();
    l.add(new ComparatorsInterface(101,"Khan",20));
    l.add(new ComparatorsInterface(102,"Amir",19));
    l.add(new ComparatorsInterface(103,"Mohsin",18));

    System.out.println("Sorted Elements By Age");
    Collections.sort(l,new AgeComparator());
    for(ComparatorsInterface c:l)
    {
        System.out.println(c.roll+" "+c.name+" "+c.age);
    }

    System.out.println("Sorted Elements By Name");
    Collections.sort(l,new NameComparator());
    for(ComparatorsInterface c:l)
    {
        System.out.println(c.roll+" "+c.name+" "+c.age);
    }
}
}