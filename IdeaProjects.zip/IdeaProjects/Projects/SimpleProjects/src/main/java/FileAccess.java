import java.io.*;
import java.sql.*;

public class FileAccess
{
    public static void main(String args[]) throws ClassNotFoundException,SQLException,IOException
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "systemroot@786");
            Statement s = con.createStatement();
            ResultSet rs = s.executeQuery("select * from file");
            rs.next();
                Clob b = rs.getClob(1);
                Reader r = b.getCharacterStream();

                FileWriter fw = new FileWriter("d://Datas.txt");
                int i;
                while ((i = r.read()) != -1)
                    fw.write((char)i);
                    fw.close();
                    con.close();
                    System.out.println("Check Your Drive");
        }
            catch(Exception e)
            {
                System.out.println(e.getMessage());
            }
        }
}
