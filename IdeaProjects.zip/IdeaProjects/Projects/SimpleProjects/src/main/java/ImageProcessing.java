import java.sql.*;
import java.io.*;

public class ImageProcessing
{
    public static void main(String[] args) throws IOException,SQLException,ClassNotFoundException
    {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","systemroot@786");
        PreparedStatement ps=con.prepareStatement("insert into image values(?,?)");
        ps.setString(1,"Char");

        File f=new File("d:\\Char.jpg");
        FileInputStream fis=new FileInputStream(f);

        ps.setBinaryStream(2,fis,(int)f.length());
        ps.executeUpdate();
        System.out.println("Successful Excecute File Of Image");
        con.close();
        ps.close();
    }
}
