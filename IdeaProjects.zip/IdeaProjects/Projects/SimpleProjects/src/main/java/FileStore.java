import java.io.*;
import java.sql.*;

public class FileStore
{
    public static void main(String[] args) throws IOException,SQLException,ClassNotFoundException
    {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","systemroot@786");
        PreparedStatement ps=c.prepareStatement("insert into file values(?)");

        File f=new File("d://JDBC.txt");
        FileReader fis=new FileReader(f);

        ps.setCharacterStream(1,fis,(int)f.length());
        ps.executeUpdate();

        System.out.println("Executed File");

    }
}
