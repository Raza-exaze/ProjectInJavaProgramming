import java.util.*;

public class CompareObject
{
    public static void main(String[] args)
    {
        Employees e=new Employees(1);
        Employees e1=new Employees(1);

        Map<Employees,Integer> m=new HashMap<Employees,Integer>();
        m.put(e,2);
        m.put(e1,2);

        System.out.println(m.size());

        Integer i=new Integer(2);
        Integer i1=new Integer(2);
        Map<Integer,String> mm=new HashMap<Integer,String>();
        mm.put(i,"one");
        mm.put(i1,"one");
        System.out.println(mm.size());

    }
}

class Employees
{
    private int id;

    public Employees(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Employees{" +
                "id=" + id +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Employees employees = (Employees) o;
        return id == employees.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
