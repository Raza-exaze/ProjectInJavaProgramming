import java.io.*;
import java.sql.*;

public class ImageAccessing
{
    public static void main(String[] args) throws IOException, SQLException, ClassNotFoundException
    {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","systemroot@786");
        Statement stm=con.createStatement();
        ResultSet rs=stm.executeQuery("select * from image");
        if(rs.next())
        {
            Blob b=rs.getBlob(2);
            byte bb[]=b.getBytes(1,(int)b.length());

            FileOutputStream fis=new FileOutputStream("d://ha.jpg");
            fis.write(bb);
            fis.close();
        }
        System.out.println("Success Load Image Check Your D Drive");
    }
}
