import java.io.*;
import java.sql.*;

public class AudioRetrieve
{
    public static void main(String[] args) throws SQLException,IOException,ClassNotFoundException
    {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Student","root","systemroot@786");
        Statement s=con.createStatement();
        ResultSet rs=s.executeQuery("select * from audio");
        try
        {
            rs.next();
            Blob b=rs.getBlob(1);
            byte[] bb=b.getBytes(1,(int)b.length());

            FileOutputStream fio=new FileOutputStream("d://new.mp3");
            fio.write(bb);
            fio.close();
            System.out.println("Successfully Done");
        }catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
    }

}
