import java.io.*;
import java.sql.*;

public class AudioFile
{
    public static void main(String[] args) throws ClassNotFoundException,SQLException,IOException
    {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","systemroot@786");
        PreparedStatement ps=con.prepareStatement("insert into audio values(?)");

        File f=new File("d:\\Audio.mp3");
        FileInputStream fis=new FileInputStream(f);

        ps.setBinaryStream(1,fis,(int)f.length());
        ps.executeUpdate();
        System.out.println("Inserted File Audio");
    }
}
