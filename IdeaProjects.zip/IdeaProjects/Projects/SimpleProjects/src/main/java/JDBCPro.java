import javax.xml.transform.Result;
import java.sql.*;

public class JDBCPro
{
    public static void main(String[] args) throws ClassNotFoundException, SQLException
    {
        Class.forName("com.mysql.jdbc.Driver");
        Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","systemroot@786");
        Statement s=c.createStatement();
        ResultSet re=s.executeQuery("select * from  country");
        int i=1;
        while(re.next())
        {
                System.out.println("Country Name:"+i+"="+re.getString(1));
                System.out.println(re.getString(2));
                i++;
        }
        c.close();
        s.close();
        re.close();
    }

}
