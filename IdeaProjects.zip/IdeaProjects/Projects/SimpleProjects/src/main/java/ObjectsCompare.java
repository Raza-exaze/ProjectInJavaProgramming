import java.util.*;

public class ObjectsCompare
{
    public static void main(String[] args)
    {
        Employee e=new Employee(1);
        Employee e1=new Employee(1);


        Map<Employee,Integer> m=new HashMap<Employee,Integer>();
        m.put(e,2);
        m.put(e1,2);
        System.out.println(m.size());

        Integer i=new Integer(2);
        Integer i1=new Integer(2);
        Map<Integer,String> mm=new HashMap<Integer,String>();
        mm.put(i,"one");
        mm.put(i1,"one");
        System.out.println(mm.size());

    }
}

class Employee
{
    private int id;

    public Employee(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                '}';
    }
}
