import java.io.*;
import java.sql.*;

public class ImageGetProcess
{
    public static void main(String[] args) throws IOException,SQLException,ClassNotFoundException
    {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","systemroot@786");
        Statement s=c.createStatement();
        ResultSet rs=s.executeQuery("select * from image");
        if(rs.next())
        {
            Blob b=rs.getBlob(2);
            byte bb[]=b.getBytes(1,(int)b.length());
            FileOutputStream fis=new FileOutputStream("d://khan.jpg");
            fis.write(bb);
            fis.close();
        }
        c.close();
        s.close();
        System.out.println("Check You D Drive");
    }
}
