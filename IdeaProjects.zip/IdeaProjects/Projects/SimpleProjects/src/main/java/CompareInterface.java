import java.util.*;
import java.io.*;

public class CompareInterface implements Comparable<CompareInterface>
{
    int roll;
    String name;
    int age;
  CompareInterface(int roll,String name,int age)
  {
      this.roll=roll;
      this.name=name;
      this.age=age;
  }
  public int compareTo(CompareInterface c)
  {
      if(age==c.age)
          return 0;
      else if(age>c.age)
          return 1;
      else
          return -1;
  }
  public static void main(String arg[])
  {
      List<CompareInterface> l=new ArrayList<CompareInterface>();
      l.add(new CompareInterface(101,"Khan",20));
      l.add(new CompareInterface(102,"Basheer",19));
      l.add(new CompareInterface(103,"Mohsin",18));
      Collections.sort(l);
      for(CompareInterface cc:l)
      {
          System.out.println(cc.roll+" "+cc.name+" "+cc.age);
      }
  }
}
