import java.sql.*;

public class Test
{
    public static void main(String[] args) throws SQLException,ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "systemroot@786");
        Statement s = con.createStatement();
        con.setAutoCommit(false);
        ResultSet rs = s.executeQuery("select * from country");
        int column = rs.findColumn("city");
        System.out.print(column);
        System.out.println();
        DatabaseMetaData db=con.getMetaData();
        System.out.println("DataBase Name:"+db.getDatabaseProductName());
        System.out.println("DataBase Version:"+db.getDatabaseProductVersion());
        System.out.println("DataBase Connection:"+db.getConnection());
        System.out.println("DataBase:"+db.getCatalogSeparator());
        System.out.println("DataBase:"+db.getDriverName());
        System.out.println("DataBase:"+db.getDriverVersion());
        System.out.println("DataBase:"+db.getDriverMajorVersion());
        System.out.println("DataBase:"+db.getDriverMinorVersion());
        s.addBatch("update country set country='China' where city='Beijing'");
        s.addBatch("update country set country='nepal' where city='kathmandu'");

        s.executeBatch();
        con.commit();
        System.out.println("Successful");

    }
}
