import java.io.*;
import java.sql.*;

public class JDBC
{
    protected static Connection initializeDatabase() throws ClassNotFoundException,SQLException,IOException
    {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","systemroot@786");

        return con;

    }
}
