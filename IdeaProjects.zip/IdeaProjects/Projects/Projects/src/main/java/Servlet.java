import java.io.*;
import java.sql.PreparedStatement;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.sql.*;

@WebServlet("/add")
public class Servlet extends HttpServlet
{
    protected void doGet(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException
    {
        try {
            Connection con = JDBC.initializeDatabase();

            PreparedStatement ps=con.prepareStatement("insert into name values(?)");

            ps.setString(1, request.getParameter("name"));
            ps.executeUpdate();
            ps.close();
            con.close();

            PrintWriter out = response.getWriter();
            out.println("<html><body><b>Successfully Inserted"
                    + "</b></body></html>");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}

