import java.sql.*;

public class MetaData
{
    public static void main(String[] args) throws ClassNotFoundException,SQLException
    {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","systemroot@786");

        DatabaseMetaData d=con.getMetaData();

        System.out.println("DataBase Name:"+d.getDriverName());
        System.out.println("DataBase Version:"+d.getDriverVersion());
        System.out.println("Driver Name:"+d.getDriverName());

        Statement st=con.createStatement();
        ResultSet rs=st.executeQuery("select * from country");

        ResultSetMetaData r=rs.getMetaData();

        System.out.println("Country Table Number Of Column:"+r.getColumnCount());
        System.out.println("Country Table:"+r.getCatalogName(2));

        st.addBatch("insert into country values('Bhutan','Thimphu')");
        st.addBatch("insert into country values('Malaysia','Kuala Lumpur')");

        int[] i=st.executeBatch();

        for(int b:i)
        {
           System.out.println("Number Of Row Inserted:"+b);
        }

    }
}
