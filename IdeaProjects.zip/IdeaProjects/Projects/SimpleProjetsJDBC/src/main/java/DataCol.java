import java.io.*;
import java.sql.*;

public class DataCol
{
    public static void main(String args[]) throws ClassNotFoundException,IOException,SQLException
    {
     Class.forName("com.mysql.cj.jdbc.Driver");
     Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","systemroot@786");
     Statement stm=con.createStatement();
     ResultSet rs=stm.executeQuery("select * from country");

     ResultSetMetaData r=rs.getMetaData();
     System.out.println("Number Of Columns:"+r.getColumnCount());
     System.out.println(r.getCatalogName(1));
     System.out.println(r.getColumnClassName(1));
     System.out.println(r.getColumnDisplaySize(2));
     sout
    }
}
