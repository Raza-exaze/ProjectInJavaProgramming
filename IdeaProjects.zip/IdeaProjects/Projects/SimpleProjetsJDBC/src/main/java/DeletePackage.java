import java.io.*;
import java.sql.*;
import java.util.Scanner;

public class DeletePackage
{
    public static void main(String[] args) throws SQLException,ClassNotFoundException,IOException
    {
       try {
           Scanner s = new Scanner(System.in);
           System.out.println("Enter Your Id:");
           String num = s.nextLine();
           Class.forName("com.mysql.cj.jdbc.Driver");
           Connection co = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "systemroot@786");
           PreparedStatement ps = co.prepareStatement("delete from student where id=?");
           ps.setString(1, num);

           int i = ps.executeUpdate();

           System.out.println("Record Delete Check Database Effected Record Row:" + i);
//           co.commit();
//           co.close();
//           ps.close();

           ResultSetMetaData rs=ps.getMetaData();

           System.out.println(rs.getColumnCount());
       }
       catch(Exception e)
       {
           System.out.println(e.getMessage());

       }
    }
}
