import java.sql.*;

class FirstApp
{
    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "systemroot@786");
            Statement stm = c.createStatement();
            ResultSet rs = stm.executeQuery("select * from country");
            while (rs.next()) {
                System.out.println(rs.getString(1));
            }
            rs.close();
            stm.close();
            c.close();
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (SQLException ee) {
            System.out.println(ee.getMessage());
        }
    }
}
