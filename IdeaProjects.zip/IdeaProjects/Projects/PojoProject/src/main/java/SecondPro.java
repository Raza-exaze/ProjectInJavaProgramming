public class SecondPro
{
    public static void main(String args[]) {
        FirstPro p = new FirstPro();
        p.setFirst_name("Mohammed");
        p.setMiddle_name("Raza");
        p.setLast_name("Ullah");


//        System.out.println(p.getFirst_name());
//        System.out.println(p.getMiddle_name());
//        System.out.println(p.getLast_name());
//        System.out.println("Candidate Name:"+p.getFirst_name()+" "+p.getMiddle_name()+p.getLast_name());
    System.out.println(p);
    }

}
