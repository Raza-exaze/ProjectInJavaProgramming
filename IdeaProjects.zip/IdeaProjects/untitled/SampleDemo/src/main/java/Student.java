import java.util.Objects;

public class Student
{
    String name;
    public Student(String name)
    {
        this.name=name;
    }

    public static void main(String args[])
    {
        Student s1=new Student("Khan");
        Student s2=new Student("Khan");

        System.out.println(s1);
        System.out.println(s2);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Student student = (Student) o;
        return Objects.equals(name, student.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }
}
