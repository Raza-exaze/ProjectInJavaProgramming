public class ArraysExample {
    public static void main(String args[]){
        int[][] a={{1,2},{2,3}};
        for(int i=0;i<a.length;i++)
        {
            for(int j=0;j<a.length;j++)
            {
                System.out.print(a[1][1]+" ");
            }
            System.out.println();
        }

    }
}
