package org.example;

import java.util.Scanner;

public class App
{
    public static void main(String[] args)
    {
        SimpleBean b=new SimpleBean();
        b.setName("Khan");
        SimpleBean b1=new SimpleBean();
        b1.setName("Mohammed");
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter Your Name:");
        String name=scan.nextLine();
        if(name.equalsIgnoreCase(b.getName()) || name.equalsIgnoreCase(b1.getName()))
        {
            System.out.println("Welcome");
            System.out.println("This Is A Java Technology Platform");
        }
        else
        {
            System.out.println("Registration Pending");
            System.out.println("First Register YourSelf");
        }
    }
}
