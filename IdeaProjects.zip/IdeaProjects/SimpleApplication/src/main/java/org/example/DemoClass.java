package org.example;

import java.util.Scanner;
import java.util.HashSet;

public class DemoClass
{
    public static void main(String args[])
    {
        System.out.println("Enter Your Name:");
        Scanner s = new Scanner(System.in);
        String name;
        for(int i=0;i<=2;i++) {
            name = s.nextLine();
            HashSet<String> hs = new HashSet<>();
            hs.add(name);
            System.out.println(hs);
            //System.out.println("HashSet Values:"+hs.hashCode());
            //System.out.println("Khan Is Available Are Not:"+hs.contains("Khan"));
        }
    }
}
