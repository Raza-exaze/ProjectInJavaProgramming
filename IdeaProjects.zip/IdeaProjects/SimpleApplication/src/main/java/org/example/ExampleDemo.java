package org.example;

import java.util.Scanner;

public class ExampleDemo
{
    public static void main(String args[])
    {
        System.out.println("Enter Your Number:");
        Scanner s=new Scanner(System.in);
        int a= s.nextInt();
        System.out.println("Enter Your Number:");
        int b=s.nextInt();
        System.out.println("Addition Of Two Numbers:"+(a+b));
        System.out.println("Multiplication Of Two Numbers:"+(a*b));
        System.out.println("Subtraction Of Two Numbers:"+(a-b));
        System.out.println("Division Of Two Numbers:"+(a/b));
        System.out.println("Modulus Of Two Numbers:"+(a%b));
    }
}
